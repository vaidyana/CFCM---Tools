#!/bin/bash
export ISGUI=true
export ESLOGPATH=.
export ESLANG=.

java -cp lib/*:TrendsViewer.jar com.earlysense.trendsviewer.TrendsViewerTool
