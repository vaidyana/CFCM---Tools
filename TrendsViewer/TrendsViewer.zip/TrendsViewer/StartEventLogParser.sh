#!/bin/bash
java -cp TrendsViewer.jar:lib/* com.earlysense.trendsviewer.EventLogParser %1
