#!/bin/bash
java -cp lib/*:dev-kit.jar com.earlysense.simulator.gui.MainScreen
